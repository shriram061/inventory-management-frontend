import React, { useState, useEffect } from 'react';
import './search.css';

export default function Search2() {
  const [products, setProducts] = useState([]);
  const [keyword, setKeyword] = useState('');
  const [sortQuantity, setSortQuantity] = useState('');
  const [sortValidity, setSortValidity] = useState('');

  function loadProducts() {
    fetch('http://localhost:9876/search?keyword=', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ keyword: keyword })
    })
      .then(response => response.json())
      .then(data => {
        const filteredProducts = data.filter(product => {
          return product.productName.toLowerCase().includes(keyword.toLowerCase());
        });

        // Apply sorting based on the current sort order
        if (sortQuantity === 'asc') {
          filteredProducts.sort((a, b) => a.quantity - b.quantity);
        } else if (sortQuantity === 'desc') {
          filteredProducts.sort((a, b) => b.quantity - a.quantity);
        }

        setProducts(filteredProducts);
      })
      .catch(error => {
        console.error(error);
      });
  }

  function handleSearch(event) {
    event.preventDefault();
    loadProducts();
  }

  function handleQuantitySort() {
    if (sortQuantity === '') {
      setSortQuantity('asc');
    } else if (sortQuantity === 'asc') {
      setSortQuantity('desc');
    } else if (sortQuantity === 'desc') {
      setSortQuantity('');
    }
  }

  return (
    <div>
      <div className="container">
        <div className="shadow  mt-4 p-5 bg-white rounded text-dark">
          <form onSubmit={handleSearch}>
            <button type="submit" className="btn btn-primary">
              Search
            </button>
          </form>
          <hr />
          <h1 className="text-center">Product Details</h1>
          <hr />
          <table className="table table-striped table-dark table-bordered">
            <thead className="thead-dark">
              <tr>
                <th>Product Id</th>
                <th>Product Name</th>
                <th>
                  Quantity
                  <button onClick={handleQuantitySort}>
                    {sortQuantity === 'asc' && <>&uarr;</>}
                    {sortQuantity === 'desc' && <>&darr;</>}
                  </button>
                </th>
                <th>
                  Validity
                  {sortQuantity === '' && (
                    <button onClick={() => setSortValidity('asc')}>
                      &uarr;
                    </button>
                  )}
                </th>
              </tr>
            </thead>
            <tbody>
              {products
                .filter(product =>
                  product.productName
                    .toLowerCase()
                    .includes(keyword.toLowerCase())
                )
                .map(product => (
                  <tr className="table-danger" key={product.productId}>
                    <td>{product.productId}</td>
                    <td>{product.productName}</td>
                    <td>{product.quantity}</td>
                    <td>{product.validity}</td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
